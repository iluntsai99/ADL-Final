import json
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained('t5-base')

maxin = maxout = 0
maxin_list = []
maxout_list = []

in_384 = 0
out_256 = 0

with open("train_processed.jsonl", 'r') as f:
	for line in f.readlines():
		line = json.loads(line)
		IN = line["IN"]
		OUT = line["OUT"]
		
		in_length, out_length = len(tokenizer(IN)["input_ids"]), len(tokenizer(OUT)["input_ids"])

		if in_length >= 384:
			in_384 += 1
		if out_length >= 256:
			out_256 += 1

		if in_length > maxin:
			maxin = in_length
			maxin_list.append(maxin)
		if out_length > maxout:
			maxout = out_length
			maxout_list.append(maxout)

print(maxin_list, maxout_list)
print(in_384, out_256) # 79, 95